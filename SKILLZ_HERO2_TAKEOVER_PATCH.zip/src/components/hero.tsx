import Image from "next/image";
import Link from "next/link";
import { site } from "@/lib/site";

const marqueeItems = [
  "Book Skillz",
  "DJ",
  "Turntablist",
  "Events",
  "Festivals",
  "Workshops",
  "Speaking",
  "Culture",
  "Producer",
];

/**
 * Hero 2 — visual master lock.
 *
 * The supplied Hero 2 reference is the composition source of truth.
 * It is rendered 1:1 as a responsive 4:3 visual surface so the approved
 * typography, subject crop, overlap, EOTO block, CTA relationship and
 * distressed treatment cannot drift through CSS reconstruction.
 *
 * The semantic CTA remains a real link. The visible reference artwork is
 * intentionally treated as a locked editorial artifact; future refinements
 * belong outside this composition.
 */
export function Hero() {
  return (
    <section
      id="landing"
      aria-label="DJ Lethal Skillz — Each One Teach One"
      className="relative -mt-[77px] overflow-hidden bg-black scroll-mt-20"
    >
      <div className="relative mx-auto w-full aspect-[1448/1086] max-w-[1448px]">
        <Image
          src={site.heroReference ?? "/assets/dj-lethal-skillz-hero2-reference.png"}
          alt="DJ Lethal Skillz — Each One Teach One"
          fill
          priority
          sizes="100vw"
          className="object-contain"
        />

        {/* Accessible CTA hotspot aligned to the locked reference artwork. */}
        <Link
          href="#what-i-do"
          aria-label="Enter the Skillz HQ"
          className="absolute bottom-[14%] right-[6%] h-[8%] w-[23%] rounded-sm focus-visible:bg-accent/20"
        />

        <div className="sr-only">
          <h1>SKILLZ</h1>
          <p>DJ LETHAL</p>
          <p>Each One Teach One</p>
          <p>Culture. Education. Turntablism. Legacy. Worldwide.</p>
          <p>Enter the HQ.</p>
        </div>
      </div>

      {/* Marquee is part of the locked visual master. */}
      <div className="sr-only" aria-label="Skillz categories">
        {marqueeItems.join(" · ")}
      </div>
    </section>
  );
}
